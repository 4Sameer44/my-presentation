## Slide 1.1

```js
var a = 1;
```


## Slide 1.2



## Slide 2